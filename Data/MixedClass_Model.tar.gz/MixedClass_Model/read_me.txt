Details for the datasets that are used:

Training set (NCV set):
MixedClass_training_210.csv

Training set + Validation sets:

Class I Close:
MixedClass_crossval_HLA-A02:02_210.csv
MixedClass_crossval_HLA-B40:02_210.csv
MixedClass_crossval_HLA-C05:01_210.csv

Class II:
MixedClass_crossval_DRB1_0102_210.csv
MixedClass_crossval_DRB1_0404_210.csv

Mouse Class II:
MixedClass_crossval_H-2-IAb_210.csv
MixedClass_denovo_H-2-IAg7_210.csv
MixedClass_denovo_H-2-IEk_210.csv
