Details for the datasets that are used:

Note, reference model datasets have _210 and _full are the full sequence datasets. 

Training set + NCV set:
ClassII_training_210.csv

Training set + Validation sets:
Humsan Class II:
ClassII_crosspred_DRB1_0102_210.csv
ClassII_crosspred_DRB1_0404_210.csv

Mouse Class II:
ClassII_crosspred_H-2-IAb_210.csv
ClassII_denovo_H-2-IAg7_210.csv
ClassII_denovo_H-2-IEk_210.csv
