Details for the datasets that are used:

Note, reference model sets have _210 and the _full are the full sequence datasets. 

Training set (NCV set):
ClassI_training_210.csv

Training set + Validation sets:

Class I Close:
ClassI_crossval_HLA-A02:02_210.csv
ClassI_crossval_HLA-B40:02_210.csv
ClassI_crossval_HLA-C05:01_210.csv

Class I Distant:
ClassI_crossval_HLA-A32:01_210.csv
ClassI_crossval_HLA-B38:01_210.csv
ClassI_crossval_HLA-C03:03_210.csv

Class II:
ClassI_crossval_DRB1_0102_210.csv
ClassI_crossval_DRB1_0404_210.csv

Mouse Class II:
ClassI_crossval_H-2-IAb_210.csv
ClassI_denovo_H-2-IAg7_210.csv
ClassI_denovo_H-2-IEk_210.csv
